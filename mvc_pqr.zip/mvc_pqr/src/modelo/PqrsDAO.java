package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import util.Conexion;

/* @author Lina */
public class PqrsDAO {
    //instancias

    Conexion conexion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List listartabla() {

        String sqlpqrs = "select * from pqrs";
        List< Pqrs> lista = new ArrayList<>();

        try {
            con = conexion.Conectar();
            ps = con.prepareStatement(sqlpqrs);
            rs = ps.executeQuery();

            while (rs.next()) {
                Pqrs pqrs = new Pqrs();

                pqrs.setIdpqrs(rs.getInt(1));
                pqrs.setF_radicado(rs.getString(2));
                pqrs.setNum_radicado(rs.getString(3));
                pqrs.setDes_pqrs(rs.getString(4));
                pqrs.setRes_pqrs(rs.getString(5));
                pqrs.setMedio_res(rs.getString(6));
                pqrs.setF_res(rs.getString(7));
                pqrs.setTipo_solicitud(rs.getString(8));
                pqrs.setId_presona(rs.getInt(9));

                lista.add(pqrs);
            }

        } catch (Exception e) {
            System.out.println("ERROR listar tabla" + e);
        }

        return lista;
    }

    public void ResponderPqrs(Pqrs pqrs) {

        String sqlUpdate = "UPDATE  pqrs SET respuesta_pqrs=?, fecha_Respuesta=? where Id_pqrs=?";

        try {
            con = conexion.Conectar();
            ps = con.prepareStatement(sqlUpdate);

            ps.setString(1, pqrs.getRes_pqrs());
            ps.setString(2, pqrs.getF_res());
            ps.setInt(3, pqrs.getIdpqrs());
            ps.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("error al responder Dao: " + ex);

        }
    }

    public List listarBuscar(String buscar) {

        String sqlBuscar = "SELECT * FROM pqrs WHERE num_Radicado like '%" + buscar + "%' ";

        List< Pqrs> listarBuscar = new ArrayList<>();

        try {
            con = conexion.Conectar();
            ps = con.prepareStatement(sqlBuscar);
            rs = ps.executeQuery();

            while (rs.next()) {
                Pqrs pqrs = new Pqrs();

                pqrs.setIdpqrs(rs.getInt(1));
                pqrs.setF_radicado(rs.getString(2));
                pqrs.setNum_radicado(rs.getString(3));
                pqrs.setDes_pqrs(rs.getString(4));
                pqrs.setRes_pqrs(rs.getString(5));
                pqrs.setMedio_res(rs.getString(6));
                pqrs.setF_res(rs.getString(7));
                pqrs.setTipo_solicitud(rs.getString(8));
                pqrs.setId_presona(rs.getInt(9));

                listarBuscar.add(pqrs);
            }

        } catch (SQLException e) {
            System.out.println("ERROR listar tabla" + e);
        }

        return listarBuscar;

    }

}
