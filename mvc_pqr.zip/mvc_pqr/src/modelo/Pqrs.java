
package modelo;
/*@author Lina*/
public class Pqrs {
    
    private int idpqrs;
    private String f_radicado;
    private String num_radicado;
    private String des_pqrs;
    private String res_pqrs;
    private String medio_res;
    private String f_res;
    private String tipo_solicitud;
    
    private int id_presona;
    private String t_iden;
    private String num_iden;
    private String nom_per;
    private String ape_per;
    private String tel_per;
    private String correo_per;
    private String dir_per;
    
     private String buscar;

    public Pqrs(String buscar) {
        this.buscar = buscar;
    }
     
     

    public String getBuscar() {
        return buscar;
    }

    public void setBuscar(String buscar) {
        this.buscar = buscar;
    }
    
     
     

    public Pqrs() {
   
    }

    public Pqrs(int idpqrs, String res_pqrs, String f_res) {
        this.idpqrs = idpqrs;
        this.res_pqrs = res_pqrs;
        this.f_res = f_res;
    }

    public Pqrs(int id_presona) {
        this.id_presona = id_presona;
    }
    
  
    
    public Pqrs(int idpqrs, String f_radicado, String num_radicado, String des_pqrs,String res_pqrs, String medio_res, 
            String f_res,String tipo_solicitud,int id_presona,String t_iden,String num_iden,String nom_per,String ape_per,
            String tel_per,String correo_per,String dir_per) {
            this.idpqrs = idpqrs;
            this.f_radicado =  f_radicado;
            this.num_radicado =num_radicado;
            this.des_pqrs = des_pqrs;
            this.res_pqrs =res_pqrs;
            this.medio_res= medio_res;
            this.f_res = f_res;
            this.tipo_solicitud = tipo_solicitud;
            this. id_presona= id_presona;
            this.t_iden =t_iden ;
            this.num_iden =num_iden ;
            this.nom_per = nom_per;
            this.ape_per =ape_per ;
            this.tel_per = tel_per;
            this.correo_per=correo_per ;
            this.dir_per = dir_per;
        
    }    

    public Pqrs(String f_radicado, String num_radicado, String des_pqrs, String res_pqrs, String medio_res, String f_res, String tipo_solicitud, int id_presona, String t_iden, String num_iden, String nom_per, String ape_per, String tel_per, String correo_per, String dir_per) {
        this.f_radicado = f_radicado;
        this.num_radicado = num_radicado;
        this.des_pqrs = des_pqrs;
        this.res_pqrs = res_pqrs;
        this.medio_res = medio_res;
        this.f_res = f_res;
        this.tipo_solicitud = tipo_solicitud;
        this.id_presona = id_presona;
        this.t_iden = t_iden;
        this.num_iden = num_iden;
        this.nom_per = nom_per;
        this.ape_per = ape_per;
        this.tel_per = tel_per;
        this.correo_per = correo_per;
        this.dir_per = dir_per;
        
    }

    
   
    
    public int getIdpqrs() {
        return idpqrs;
    }

    

    public void setIdpqrs(int idpqrs) {
        this.idpqrs = idpqrs;
    }

    public String getF_radicado() {
        return f_radicado;
    }

    public void setF_radicado(String f_radicado) {
        this.f_radicado = f_radicado;
    }

    public String getNum_radicado() {
        return num_radicado;
    }

    public void setNum_radicado(String num_radicado) {
        this.num_radicado = num_radicado;
    }

    public String getDes_pqrs() {
        return des_pqrs;
    }

    public void setDes_pqrs(String des_pqrs) {
        this.des_pqrs = des_pqrs;
    }

    public String getRes_pqrs() {
        return res_pqrs;
    }

    public void setRes_pqrs(String res_pqrs) {
        this.res_pqrs = res_pqrs;
    }

    public String getMedio_res() {
        return medio_res;
    }

    public void setMedio_res(String medio_res) {
        this.medio_res = medio_res;
    }

    public String getF_res() {
        return f_res;
    }

    public void setF_res(String f_res) {
        this.f_res = f_res;
    }

    public String getTipo_solicitud() {
        return tipo_solicitud;
    }

    public void setTipo_solicitud(String tipo_solicitud) {
        this.tipo_solicitud = tipo_solicitud;
    }

    public int getId_presona() {
        return id_presona;
    }

    public void setId_presona(int id_presona) {
        this.id_presona = id_presona;
    }

   

    public String getT_iden() {
        return t_iden;
    }

    public void setT_iden(String t_iden) {
        this.t_iden = t_iden;
    }

    public String getNum_iden() {
        return num_iden;
    }

    public void setNum_iden(String num_iden) {
        this.num_iden = num_iden;
    }

    public String getNom_per() {
        return nom_per;
    }

    public void setNom_per(String nom_per) {
        this.nom_per = nom_per;
    }

    public String getApe_per() {
        return ape_per;
    }

    public void setApe_per(String ape_per) {
        this.ape_per = ape_per;
    }

    public String getTel_per() {
        return tel_per;
    }

    public void setTel_per(String tel_per) {
        this.tel_per = tel_per;
    }

    public String getCorreo_per() {
        return correo_per;
    }

    public void setCorreo_per(String correo_per) {
        this.correo_per = correo_per;
    }

    public String getDir_per() {
        return dir_per;
    }

    public void setDir_per(String dir_per) {
        this.dir_per = dir_per;
    }
    
    
    
}
