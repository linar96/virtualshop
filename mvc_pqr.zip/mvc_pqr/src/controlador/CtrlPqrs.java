package controlador;

import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;

import javax.swing.table.DefaultTableModel;
import modelo.Pqrs;
import modelo.PqrsDAO;
import vista.FrmPqrs;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTable;


/*@author Lina*/
public class CtrlPqrs implements ActionListener {

    FrmPqrs frm = new FrmPqrs();
    Pqrs pqrs = new Pqrs();
    PqrsDAO pqrsDAO = new PqrsDAO();
    DefaultTableModel modelo = new DefaultTableModel();

    private int idpqrsctrl;
    private int id_personactrl;
    private String buscar_ctrl;
    private String f_resctrl;
    private String res_pqrsctrl;
 

    public CtrlPqrs(FrmPqrs frm) {
        this.frm = frm;
        frm.setVisible(true);
        frm.setLocationRelativeTo(null);
        frm.setTitle("PQRS");
        agregarEventos();
        ListarTabla();

    }

    private void ListarTabla() {

        try {
            String[] titulos = new String[]{
                "ID PQRS", "Fecha_Radicación", "N°_Radiado", "Descripcion", "Respuesta", "Medio_Respuesta", "Fecha_Respuesta", "Tipo_Solicitud", "ID_Comprador"};
            modelo = new DefaultTableModel(titulos, 0);

            List<Pqrs> listapqrs = pqrsDAO.listartabla();

            listapqrs.forEach((i) -> {
                modelo.addRow(new Object[]{i.getIdpqrs(), i.getF_radicado(), i.getNum_radicado(),
                    i.getDes_pqrs(), i.getRes_pqrs(), i.getMedio_res(), i.getF_res(), i.getTipo_solicitud(), i.getId_presona()});
            });

            frm.getTablaPqrs().setModel(modelo);
            frm.getTablaPqrs().setPreferredSize(new Dimension(350, modelo.getRowCount() * 16));

        } catch (Exception e) {
            System.out.println("ERROR listar tabla ctrl" + e);
        }

    }

    private void buscar() {
        if (CargarDatos()) {

            try {
                pqrsDAO.listarBuscar(buscar_ctrl);

                String[] titulos = new String[]{
                    "ID PQRS", "Fecha_Radicación", "N°_Radiado", "Descripcion", "Respuesta", "Medio_Respuesta", "Fecha_Respuesta", "Tipo_Solicitud", "ID_Comprador"};
                modelo = new DefaultTableModel(titulos, 0);

                List<Pqrs> listapqrs = pqrsDAO.listarBuscar(buscar_ctrl);
              
                if (listapqrs.isEmpty()) {

                    JOptionPane.showMessageDialog(null, "Radicado no Encotrado");

                } else {
                    listapqrs.forEach((i) -> {
                        modelo.addRow(new Object[]{i.getIdpqrs(), i.getF_radicado(), i.getNum_radicado(),
                            i.getDes_pqrs(), i.getRes_pqrs(), i.getMedio_res(), i.getF_res(), i.getTipo_solicitud(), i.getId_presona()});
                    });

                    frm.getTablaPqrs().setModel(modelo);
                    frm.getTablaPqrs().setPreferredSize(new Dimension(350, modelo.getRowCount() * 16));
                }
            } catch (Exception e) {
                System.out.println("ERROR listar tabla ctrl" + e);
            }

        }
    } 

    private boolean CargarDatos() {
        try {

            buscar_ctrl = frm.getTxtbuscar().getText();
            res_pqrsctrl = frm.getTxtres().getText();
            f_resctrl = frm.getTxtfechares().getText();

            return true;

        } catch (Exception e) {
            System.out.println("ERROR cargar datos" + e);
            return false;
        }

    }

    private boolean ValidarDatos() {

        if ("".equals(frm.getTxtres().getText()) || "".equals(frm.getTxtfechares().getText())) {

            JOptionPane.showMessageDialog(null, "Campos Vacios");

            return false;

        }
        return true;
    }

    private void Responder() {

        try {

            if (ValidarDatos()) {
                    
                if (CargarDatos()) {

                    Pqrs vl = new Pqrs(idpqrsctrl, res_pqrsctrl, f_resctrl);
                    pqrsDAO.ResponderPqrs(vl);
                    JOptionPane.showMessageDialog(null, "Respuesta Cargada");
                }
            }

        } catch (HeadlessException e) {
            System.out.println("ERROR al Subir Respuesta ctrl" + e);
        } finally {
            LimpiarCampos();
            ListarTabla();

        }

    }

    private void agregarEventos() {

        frm.getBtnguardar().addActionListener(this);
        frm.getBtnlimpiar().addActionListener(this);
        frm.getBtnBuscar().addActionListener(this);

        frm.getTablaPqrs().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                LimpiarCampos();
                llenarCampos(e);
               

            }
        });

    }

    private void llenarCampos(MouseEvent e) {

        JTable target = (JTable) e.getSource();

        idpqrsctrl = (int) frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 0);

        frm.getTxtfechar().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 1).toString());
        frm.getTxtnumradicado().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 2).toString());
        frm.getTxtdes().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 3).toString());

        frm.getTxtmediores().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 5).toString());

        frm.getTxttipos().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 7).toString());
        id_personactrl = (int) frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 8);
        
        
        frm.getTxtres().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 4).toString());
        
        frm.getTxtfechares().setText(frm.getTablaPqrs().getModel().getValueAt(target.getSelectedRow(), 6).toString());

    }

    private void LimpiarCampos() {
        
        frm.getTxrnumradicado().setText("");
        frm.getTxtfechar().setText("");
        frm.getTxttipos().setText("");
        frm.getTxtfechares().setText("");
        frm.getTxttipod().setText("");
        frm.getTxtnumd().setText("");
        frm.getTxtnom().setText("");
        frm.getTxtape().setText("");
        frm.getTxtcelular().setText("");
        frm.getTxtcorreo().setText("");
        frm.getTxtdir().setText("");
        frm.getTxtmediores().setText("");
        frm.getTxtdes().setText("");
        frm.getTxtres().setText("");
        frm.getTxtbuscar().setText("");
        idpqrsctrl = 0;
        id_personactrl = 0;
         buscar_ctrl="";

    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == frm.getBtnlimpiar()) {
            LimpiarCampos();
        }
         if (ae.getSource() == frm.getBtnguardar()) {
            Responder();
        }
        if (ae.getSource() == frm.getBtnBuscar()) {
            buscar();
        }

    }

}
